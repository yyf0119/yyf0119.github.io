$(function () {
$(document).ready(function(){
	var divs;
divs = new Array("#div1","#div2","#div3","#div4","#div5","#div6","#div7","#div8","#div9","#div10","#div11","#div12","#div13","#div14","#div15","#div16","#div17","#div18","#div19","#div20","#div21","#div22","#div23","#div24","#div25","#div26","#div27","#div28","#div29","#div30","#div31","#div32","#div33","#div34","#div35","#div36","#div37","#div38","#div39","#div40","#div41","#div42","#div43","#div44","#div45","#div46","#div47","#div48","#div49","#div50","#div51","#div52","#div53","#div54","#div55","#div56");

var i=0;
for(i;i<divs.length;i++)
	{ 
	  $(divs[i]).hide();
	
 	}
	 
  $("#t1").mouseenter(function(){
    $("#div1").show();$("#div57").hide();
  });
  $("#t1").mouseleave(function(){
     $("#div1").hide();$("#div57").show();
  });
  
  $("#t2").mouseenter(function(){
    $("#div2").show();$("#div57").hide();     
  });
   $("#t2").mouseleave(function(){
     $("#div2").hide();$("#div57").show();
  });
	
  $("#t3").mouseenter(function(){
    $("#div3").show();$("#div57").hide();     
  });
   $("#t3").mouseleave(function(){
     $("#div3").hide();$("#div57").show();
  });
  
  $("#t4").mouseenter(function(){
    $("#div4").show();$("#div57").hide();     
  });
   $("#t4").mouseleave(function(){
     $("#div4").hide();$("#div57").show();
  });
  
   $("#t5").mouseenter(function(){
    $("#div5").show();$("#div57").hide();     
  });
   $("#t5").mouseleave(function(){
     $("#div5").hide();$("#div57").show();
  });
  
   $("#t6").mouseenter(function(){
    $("#div6").show();$("#div57").hide();     
  });
   $("#t6").mouseleave(function(){
     $("#div6").hide();$("#div57").show();
  });
  
   $("#t7").mouseenter(function(){
    $("#div7").show();$("#div57").hide();     
  });
   $("#t7").mouseleave(function(){
     $("#div7").hide();$("#div57").show();
  });
  
   $("#t8").mouseenter(function(){
    $("#div8").show();$("#div57").hide();     
  });
   $("#t8").mouseleave(function(){
     $("#div8").hide();$("#div57").show();
  });
  
   $("#t9").mouseenter(function(){
    $("#div9").show();$("#div57").hide();     
  });
   $("#t9").mouseleave(function(){
     $("#div9").hide();$("#div57").show();
  });
  	 
  $("#t10").mouseenter(function(){
    $("#div10").show();$("#div57").hide();     
  });
  $("#t10").mouseleave(function(){
     $("#div10").hide();$("#div57").show();
  });
  	 
  $("#t11").mouseenter(function(){
    $("#div11").show();$("#div57").hide();     
  });
  $("#t11").mouseleave(function(){
     $("#div11").hide();$("#div57").show();
  });
  	 
  $("#t12").mouseenter(function(){
    $("#div12").show();$("#div57").hide();     
  });
  $("#t12").mouseleave(function(){
     $("#div12").hide();$("#div57").show();
  });
  	 
  $("#t13").mouseenter(function(){
    $("#div13").show();$("#div57").hide();     
  });
  $("#t13").mouseleave(function(){
     $("#div13").hide();$("#div57").show();
  });
  	 
  $("#t14").mouseenter(function(){
    $("#div14").show();$("#div57").hide();     
  });
  $("#t14").mouseleave(function(){
     $("#div14").hide();$("#div57").show();
  });
  	 
  $("#t15").mouseenter(function(){
    $("#div15").show();$("#div57").hide();     
  });
  $("#t15").mouseleave(function(){
     $("#div15").hide();$("#div57").show();
  });
  	 
  $("#t16").mouseenter(function(){
    $("#div16").show();$("#div57").hide();     
  });
  $("#t16").mouseleave(function(){
     $("#div16").hide();$("#div57").show();
  });
  	 
  $("#t17").mouseenter(function(){
    $("#div17").show();$("#div57").hide();     
  });
  $("#t17").mouseleave(function(){
     $("#div17").hide();$("#div57").show();
  });
  	 
  $("#t18").mouseenter(function(){
    $("#div18").show();$("#div57").hide();     
  });
  $("#t18").mouseleave(function(){
     $("#div18").hide();$("#div57").show();
  });
  	 
  $("#t19").mouseenter(function(){
    $("#div19").show();$("#div57").hide();     
  });
  $("#t19").mouseleave(function(){
     $("#div19").hide();$("#div57").show();
  });
  
  $("#t20").mouseenter(function(){
    $("#div20").show();$("#div57").hide();     
  });
   $("#t20").mouseleave(function(){
     $("#div20").hide();$("#div57").show();
  });
	
  $("#t21").mouseenter(function(){
    $("#div21").show();$("#div57").hide();     
  });
   $("#t21").mouseleave(function(){
     $("#div21").hide();$("#div57").show();
  });
	
  $("#t22").mouseenter(function(){
    $("#div22").show();$("#div57").hide();     
  });
   $("#t22").mouseleave(function(){
     $("#div22").hide();$("#div57").show();
  });
	
  $("#t23").mouseenter(function(){
    $("#div23").show();$("#div57").hide();     
  });
   $("#t23").mouseleave(function(){
     $("#div23").hide();$("#div57").show();
  });
	
  $("#t24").mouseenter(function(){
    $("#div24").show();$("#div57").hide();     
  });
   $("#t24").mouseleave(function(){
     $("#div24").hide();$("#div57").show();
  });
	
  $("#t25").mouseenter(function(){
    $("#div25").show();$("#div57").hide();     
  });
   $("#t25").mouseleave(function(){
     $("#div25").hide();$("#div57").show();
  });
	
  $("#t26").mouseenter(function(){
    $("#div26").show();$("#div57").hide();     
  });
   $("#t26").mouseleave(function(){
     $("#div26").hide();$("#div57").show();
  });
	
  $("#t27").mouseenter(function(){
    $("#div27").show();$("#div57").hide();     
  });
   $("#t27").mouseleave(function(){
     $("#div27").hide();$("#div57").show();
  });
	
  $("#t28").mouseenter(function(){
    $("#div28").show();$("#div57").hide();     
  });
   $("#t28").mouseleave(function(){
     $("#div28").hide();$("#div57").show();
  });
	
  $("#t29").mouseenter(function(){
    $("#div29").show();$("#div57").hide();     
  });
   $("#t29").mouseleave(function(){
     $("#div29").hide();$("#div57").show();
  });
		
  $("#t30").mouseenter(function(){
    $("#div30").show();$("#div57").hide();     
  });
   $("#t30").mouseleave(function(){
     $("#div30").hide();$("#div57").show();
  });
  	
  $("#t31").mouseenter(function(){
    $("#div31").show();$("#div57").hide();     
  });
   $("#t31").mouseleave(function(){
     $("#div31").hide();$("#div57").show();
  });
  	
  $("#t32").mouseenter(function(){
    $("#div32").show();$("#div57").hide();     
  });
   $("#t32").mouseleave(function(){
     $("#div32").hide();$("#div57").show();
  });
  	
  $("#t33").mouseenter(function(){
    $("#div33").show();$("#div57").hide();     
  });
   $("#t33").mouseleave(function(){
     $("#div33").hide();$("#div57").show();
  });
  	
  $("#t34").mouseenter(function(){
    $("#div34").show();$("#div57").hide();     
  });
   $("#t34").mouseleave(function(){
     $("#div34").hide();$("#div57").show();
  });
  	
  $("#t35").mouseenter(function(){
    $("#div35").show();$("#div57").hide();     
  });
   $("#t35").mouseleave(function(){
     $("#div35").hide();$("#div57").show();
  });
  	
  $("#t36").mouseenter(function(){
    $("#div36").show();$("#div57").hide();     
  });
   $("#t36").mouseleave(function(){
     $("#div36").hide();$("#div57").show();
  });
  	
  $("#t37").mouseenter(function(){
    $("#div37").show();$("#div57").hide();     
  });
   $("#t37").mouseleave(function(){
     $("#div37").hide();$("#div57").show();
  });
  	
  $("#t38").mouseenter(function(){
    $("#div38").show();$("#div57").hide();     
  });
   $("#t38").mouseleave(function(){
     $("#div38").hide();$("#div57").show();
  });
  	
  $("#t39").mouseenter(function(){
    $("#div39").show();$("#div57").hide();     
  });
   $("#t39").mouseleave(function(){
     $("#div39").hide();$("#div57").show();
  });
    
  $("#t40").mouseenter(function(){
    $("#div40").show();$("#div57").hide();     
  });
   $("#t40").mouseleave(function(){
     $("#div40").hide();$("#div57").show();
  });
    
  $("#t41").mouseenter(function(){
    $("#div41").show();$("#div57").hide();     
  });
   $("#t41").mouseleave(function(){
     $("#div41").hide();$("#div57").show();
  });
    
  $("#t42").mouseenter(function(){
    $("#div42").show();$("#div57").hide();     
  });
   $("#t42").mouseleave(function(){
     $("#div42").hide();$("#div57").show();
  });
    
  $("#t43").mouseenter(function(){
    $("#div43").show();$("#div57").hide();     
  });
   $("#t43").mouseleave(function(){
     $("#div43").hide();$("#div57").show();
  });
    
  $("#t44").mouseenter(function(){
    $("#div44").show();$("#div57").hide();     
  });
   $("#t44").mouseleave(function(){
     $("#div44").hide();$("#div57").show();
  });
    
  $("#t45").mouseenter(function(){
    $("#div45").show();$("#div57").hide();     
  });
   $("#t45").mouseleave(function(){
     $("#div45").hide();$("#div57").show();
  });
    
  $("#t46").mouseenter(function(){
    $("#div46").show();$("#div57").hide();     
  });
   $("#t46").mouseleave(function(){
     $("#div46").hide();$("#div57").show();
  });
    
  $("#t47").mouseenter(function(){
    $("#div47").show();$("#div57").hide();     
  });
   $("#t47").mouseleave(function(){
     $("#div47").hide();$("#div57").show();
  });
    
  $("#t48").mouseenter(function(){
    $("#div48").show();$("#div57").hide();     
  });
   $("#t48").mouseleave(function(){
     $("#div48").hide();$("#div57").show();
  });
    
  $("#t49").mouseenter(function(){
    $("#div49").show();$("#div57").hide();     
  });
   $("#t49").mouseleave(function(){
     $("#div49").hide();$("#div57").show();
  });
    
   $("#t50").mouseenter(function(){
    $("#div50").show();$("#div57").hide();     
  });
   $("#t50").mouseleave(function(){
     $("#div50").hide();$("#div57").show();
  });
  
  
   $("#t51").mouseenter(function(){
    $("#div51").show();$("#div57").hide();     
  });
   $("#t51").mouseleave(function(){
     $("#div51").hide();$("#div57").show();
  });
  
  
   $("#t52").mouseenter(function(){
    $("#div52").show();$("#div57").hide();     
  });
   $("#t52").mouseleave(function(){
     $("#div52").hide();$("#div57").show();
  });
  
  
   $("#t53").mouseenter(function(){
    $("#div53").show();$("#div57").hide();     
  });
   $("#t53").mouseleave(function(){
     $("#div53").hide();$("#div57").show();
  });
  
  
   $("#t54").mouseenter(function(){
    $("#div54").show();$("#div57").hide();     
  });
   $("#t54").mouseleave(function(){
     $("#div54").hide();$("#div57").show();
  });
  
  
   $("#t55").mouseenter(function(){
    $("#div55").show();$("#div57").hide();     
  });
   $("#t55").mouseleave(function(){
     $("#div55").hide();$("#div57").show();
  });
  
   $("#t56").mouseenter(function(){
    $("#div56").show();$("#div57").hide();     
  });
   $("#t56").mouseleave(function(){
     $("#div56").hide();$("#div57").show();
  });
  
});

<!--以上是js初始化-->

	$.getJSON( "json/china.json" ).done(function ( response,color) {
        color="#FF8247"
	
         jsMap.config( "#map-01", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {
                    neimenggu: color,
					heilongjiang: color,
					jilin:color,
					liaoning: color,
					hebei:color,
					xinjiang: color,
					ningxia: color,
					gansu: color,
					qinghai: color,
				
               }
            }
			
		});
		<!--蒙古族-->
		
		jsMap.config( "#map-02", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {
                    neimenggu: color,
					hebei: color,
					beijing:color,
					liaoning: color,
					anhui:color,
					xinjiang: color,
					shandong: color,
					gansu: color,
					henan: color,
					yunnan: color,
					
				
               }
            }
		});
		<!--回族-->
		
		jsMap.config( "#map-03", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {
                    qinghai: color,
					sichuan:color,
					xizang: color,
					gansu: color,
					yunnan: color,	
				
               }
            }
		});
		<!--藏族-->
		
		
		jsMap.config( "#map-04", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {
                    hunan: color,
					henan:color,
					xinjiang: color,			
				
               }
            }
		});
		<!--维吾尔族-->
		
		jsMap.config( "#map-05", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {
                    hunan: color,
					hubei:color,
					guizhou: color,
					sichuan: color,
					yunnan: color,
					guangxi: color,
					hainan: color,
				
               }
            }
		});
		<!--苗族-->
				
		jsMap.config( "#map-06", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					guizhou: color,
					sichuan: color,
					yunnan: color,
					guangxi: color,
								
               }
            }
		});
		<!--彝族-->
	
		jsMap.config( "#map-07", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					guizhou: color,
					guangdong: color,
					yunnan: color,
					guangxi: color,
								
               }
            }
		});
		<!--壮族-->
		
		jsMap.config( "#map-08", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					guizhou: color,
					yunnan: color,
					sichuan: color,
								
               }
            }
		});
		<!--布依族-->
	
		jsMap.config( "#map-09", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					jilin: color,
					heilongjiang: color,
					liaoning: color,
					
               }
            }
		});
		<!--朝鲜族-->
	
		jsMap.config( "#map-10", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					hebei:color,
					beijing:color,
					neimenggu:color,
					jilin: color,
					heilongjiang: color,
					liaoning: color,
								
               }
            }
		});
		<!--满族-->
	
		jsMap.config( "#map-11", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					guizhou: color,
					guangdong: color,
					yunnan: color,
					guangxi: color,
								
               }
            }
		});
		<!--侗族-->
	
		jsMap.config( "#map-12", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					hunan:color,
					jiangxi:color,
					guizhou: color,
					guangdong: color,
					yunnan: color,
					guangxi: color,
								
               }
            }
		});
		<!--瑶族-->

		jsMap.config( "#map-13", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					guizhou: color,
					hunan: color,
					yunnan: color,
								
               }
            }
		});
		<!--白族-->
							
	
		jsMap.config( "#map-14", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					guizhou: color,
					hunan: color,
					hubei: color,
					chongqing: color,
								
               }
            }
		});
		<!--土家族-->
						
	
		jsMap.config( "#map-15", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					yunnan: color,
								
               }
            }
		});
		<!--哈尼族-->
						
	
		jsMap.config( "#map-16", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					xinjiang: color,
					gansu: color,
					qinghai: color,
								
               }
            }
		});
		<!--哈萨克族-->
						
	
		jsMap.config( "#map-17", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
		
					yunnan: color,
					
               }
            }
		});
		<!--傣族-->
						
	
		jsMap.config( "#map-18", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
								
					hainan: color,
								
               }
            }
		});
		<!--黎族-->
						
	
		jsMap.config( "#map-19", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					yunnan: color,
					xizang: color,
								
               }
            }
		});
		<!--傈僳族-->
						
	
		jsMap.config( "#map-20", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					yunnan: color,
								
               }
            }
		});
		<!--佤族-->
	
		jsMap.config( "#map-21", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {   
				              
					fujian: color,
					zhejiang: color,
									
               }
            }
		});
		<!--畲族-->
		
		jsMap.config( "#map-22", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					taiwan: color,
					fujian: color,
					zhejiang: color,
								
               }
            }
		});
		<!--高山族-->
		
		jsMap.config( "#map-23", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					yunnan: color,
					
               }
            }
		});
		<!--拉祜族-->
		
		jsMap.config( "#map-24", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					guizhou: color,
					yunnan: color,
					guangxi: color,
								
               }
            }
		});
		<!--水族-->
		
		jsMap.config( "#map-25", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					gansu: color,
								
               }
            }
		});
		<!--东乡族-->
		
		jsMap.config( "#map-26", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					yunnan: color,
								
               }
            }
		});
		<!--纳西族-->
		
		jsMap.config( "#map-27", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 

					yunnan: color,
								
               }
            }
		});
		<!--景颇族-->
		
		jsMap.config( "#map-28", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					xinjiang: color,
								
               }
            }
		});
		<!--柯尔克孜族-->
		
		jsMap.config( "#map-29", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					qinghai: color,
					gansu: color,
								
               }
            }
		});
		<!--土族-->
		
		jsMap.config( "#map-30", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					neimenggu: color,
					heilongjiang: color,
								
               }
            }
		});
		<!--达斡尔族-->
		
		jsMap.config( "#map-31", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					guizhou: color,
					guangxi: color,
								
               }
            }
		});
		<!--仫佬族-->
					
		jsMap.config( "#map-32", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					sichuan: color,
								
               }
            }
		});
		<!--羌族-->
					
		jsMap.config( "#map-33", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 

					yunnan: color,
					
               }
            }
		});
		<!--布朗族-->
					
		jsMap.config( "#map-34", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					qinghai: color,
					gansu: color,
								
               }
            }
		});
		<!--撒拉族-->
					
		jsMap.config( "#map-35", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					guizhou: color,
					guangxi: color,
								
               }
            }
		});
		<!--毛南族-->
					
		jsMap.config( "#map-36", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					guizhou: color,
								
               }
            }
		});
		<!--仡佬族-->
					
		jsMap.config( "#map-37", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					liaoning: color,
					xinjiang: color,
								
               }
            }
		});
		<!--锡伯族-->
					
		jsMap.config( "#map-38", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 

					yunnan: color,
								
               }
            }
		});
		<!--阿昌族-->
					
		jsMap.config( "#map-39", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					sichuan: color,
					yunnan: color,
								
               }
            }
		});
		<!--普米族-->
					
		jsMap.config( "#map-40", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					xinjiang: color,
								
               }
            }
		});
		<!--塔吉克族-->
					
		jsMap.config( "#map-41", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					yunnan: color,
					xizang: color,
								
               }
            }
		});
		<!--怒族-->
										
					
		jsMap.config( "#map-42", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 

					xinjiang: color,
								
               }
            }
		});
		<!--乌孜别克族-->
										
					
		jsMap.config( "#map-43", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					xinjiang: color,
					neimenggu: color,
					beijing: color,
					heilongjiang: color,
								
               }
            }
		});
		<!--俄罗斯族-->
										
					
		jsMap.config( "#map-44", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
							
					neimenggu: color,
					heilongjiang: color,
								
               }
            }
		});
		<!--鄂温克族-->
										
					
		jsMap.config( "#map-45", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 

					yunnan: color,
								
               }
            }
		});
		<!--德昂族-->
										
					
		jsMap.config( "#map-46", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					ningxia: color,
					lanzhou: color,
					xinjiang: color,
								
               }
            }
		});
		<!--保安族-->
										
					
		jsMap.config( "#map-47", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					gansu: color,
								
               }
            }
		});
		<!--裕固族-->
										
					
		jsMap.config( "#map-48", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					guangxi: color,
								
               }
            }
		});
		<!--京族-->
										
					
		jsMap.config( "#map-49", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					xinjiang: color,
								
               }
            }
		});
		<!--塔塔尔族-->
										
					
		jsMap.config( "#map-50", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 

					yunnan: color,
					xizang: color,
								
               }
            }
		});
		<!--独龙族-->
					
		jsMap.config( "#map-51", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					neimenggu: color,
					heilongjiang: color,
								
               }
            }
		});
		<!--鄂伦春族-->
						
		jsMap.config( "#map-52", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					heilongjiang: color,
								
               }
            }
		});
		<!--赫哲族-->
						
		jsMap.config( "#map-53", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
					
					xizang: color,
								
               }
            }
		});
		<!--门巴族-->
						
		jsMap.config( "#map-54", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 

					xizang: color,
								
               }
            }
		});
		<!--珞巴族-->
						
		jsMap.config( "#map-55", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 

					yunnan: color,
								
               }
            }
		});
		<!--基诺族-->
											
		jsMap.config( "#map-56", response, {
			 areaName: {
				show: true
			},
			fill: {
                basicColor: {                 
                    xinjiang:color,
					xizang:color,
					ningxia:color,
					guangxi:color,
					guangdong:color,
					neimenggu:color,
					gansu:color,
					sichuan:color,
					heilongjiang:color,
					jilin:color,
					liaoning:color,
					hebei:color,
					beijing:color,
					tianjin:color,
					shandong:color,
					henan:color,
					hunan:color,
					shanghai:color,
					hainan:color,
					guizhou:color,
					anhui:color,
					fujian:color,
					jiangxi:color,
					chongqing:color,
					shanxi:color,
					jiangsu:color,
					hubei:color,
					hebei:color,
					shaanxi:color,
					qinghai:color,
					taiwan:color,
					zhejiang:color,
					yunnan: color,
								
               }
            }
		});
		<!--汉族-->								
	
				jsMap.config( "#map-57", response, {
			 areaName: {
				show: true
			},
			
            
		});
		<!--空地图-->
		
		
		
})
})